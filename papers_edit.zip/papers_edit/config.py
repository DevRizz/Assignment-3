# config.py - System Configuration
# Author: Saharsh Kumar, 3796540
# Purpose: Centralized configuration for aircraft telemetry and ground station network

import os

# Ground Station Network Configuration
GROUND_STATIONS = [
    {"host": "127.0.0.1", "port": 9000, "name": "GS-Primary"},
    {"host": "127.0.0.1", "port": 9001, "name": "GS-Backup"},
]

# Network & Communication
ACK_PORT = 9100  # Port for acknowledgments from ground stations
CHUNK_SIZE = 900  # Size of each data chunk in bytes

# Cryptography & Keys
PRIVATE_KEY_PATH = "keys/aircraft_private.pem"
PUBLIC_KEY_PATH = "keys/aircraft_public.pem"
HMAC_KEY = b"fdr-hmac-shared-2024"

# DTN (Delay Tolerant Network) Retry Configuration
DTN_BASE_SEC = 1.0
DTN_MAX_SEC = 30.0
DTN_MAX_RETRIES = 10
DTN_STATE_FILE = "output/dtn_state.json"

# Telemetry Duration
DURATION_SEC = 60

# Audio file path (adjust to your environment)
CVR_AUDIO_PATH = None  # Set to audio file path if available, else None for synthetic

# Network Simulation Parameters (for testing)
NET_DROP_PROB = 0.08  # 8% packet drop probability
NET_BURST_SIZE = 3  # Consecutive losses in burst
NET_BLACKOUT_START_S = 20  # Simulated blackout window start (seconds)
NET_BLACKOUT_END_S = 35    # Simulated blackout window end (seconds)
NET_BASE_LATENCY_MS = 40   # Base network latency (milliseconds)
NET_JITTER_MS = 15         # Jitter variation (milliseconds)