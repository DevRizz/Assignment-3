# compress.py - Data Compression and Bundle Management
# Author: Saharsh Kumar, 3796540
# Purpose: Handle telemetry/audio compression with bundle formatting and verification

import hashlib
import struct
import time
import zlib
import bz2
import lzma
import audioop

# Bundle header format and constants
BUNDLE_MAGIC = b"FDRBNDL5"  # Magic number to identify valid bundles
# Format: magic(8) + session_id(32) + tele_algo(1) + audio_algo(1) + 
#         tele_raw_len(4) + tele_comp_len(4) + audio_raw_len(4) + audio_comp_len(4) + 
#         ext(5) + sha256(32) = 94 bytes total
BUNDLE_FMT = "!8s32sBBIIII5s32s"
BUNDLE_HDR_SZ = struct.calcsize(BUNDLE_FMT)

# Compression algorithms available for telemetry data
TELE_ALGOS = {
    "zlib": (1, lambda d: zlib.compress(d, 9), zlib.decompress),  # Good compression
    "bz2": (2, lambda d: bz2.compress(d, 9), bz2.decompress),     # Better compression
    "lzma": (3, lzma.compress, lzma.decompress),                  # Best compression
}

# Audio encoding/decoding functions
def adpcm_encode(d):
    # ADPCM requires an even number of bytes for 16-bit (2-byte) samples
    if len(d) % 2 != 0:
        d += b'\x00'
    # audioop.lin2adpcm returns (adpcm_data, final_state)
    # We only want the data [0]
    return audioop.lin2adpcm(d, 2, None)[0]

def adpcm_decode(d):
    # Decode ADPCM back to PCM format
    return audioop.adpcm2lin(d, 2, None)[0]

# Audio encoding methods
AUDIO_ALGOS = {
    "pcm_raw": (1, lambda d: d, lambda d: d),  # Raw PCM (passthrough)
    "adpcm": (2, adpcm_encode, adpcm_decode),  # ADPCM compression
}

def compress_bundle(session_id: bytes, tele_raw: bytes, audio_raw: bytes, 
                    audio_ext: str = ".wav") -> tuple[bytes, list]:
    """
    Compress telemetry and audio data into a signed bundle.
    Tests multiple compression algorithms and picks the best one.
    """
    
    # Test all available telemetry compression algorithms
    tele_results = []
    for name, (id_val, cfn, dfn) in TELE_ALGOS.items():
        t0 = time.perf_counter()
        tc_temp = cfn(tele_raw)
        elapsed = (time.perf_counter() - t0) * 1000
        
        # Calculate compression ratio
        ratio = len(tele_raw) / len(tc_temp) if len(tc_temp) > 0 else 1.0
        
        # Verify the algorithm preserves data integrity
        if dfn(tc_temp) == tele_raw:
            tele_results.append({
                "name": name, 
                "id": id_val, 
                "data": tc_temp, 
                "ms": elapsed,
                "ratio": ratio
            })
    
    # Select the best compression algorithm by size
    best_tele = min(tele_results, key=lambda x: len(x["data"]))
    tc = best_tele["data"]
    
    # Use PCM raw for audio (no additional compression)
    audio_algo_name = "pcm_raw"
    a_id, a_cfn, _ = AUDIO_ALGOS[audio_algo_name]
    ac = a_cfn(audio_raw)

    # Create bundle header
    ext_b = audio_ext.encode()[:5].ljust(5, b"\x00")
    integrity = hashlib.sha256(tc + ac).digest()
    
    # Pack header with all metadata
    header = struct.pack(BUNDLE_FMT,
        BUNDLE_MAGIC, session_id, 
        best_tele["id"], a_id,
        len(tele_raw), len(tc), 
        len(audio_raw), len(ac), 
        ext_b, integrity)

    print(f"Telemetry: {best_tele['name'].upper()} ({len(tele_raw):,}B -> {len(tc):,}B, ratio: {best_tele['ratio']:.2f}x)")
    print(f"Audio: PCM_RAW ({len(audio_raw):,}B)")
    
    return header + tc + ac, tele_results

def decompress_bundle(bundle: bytes) -> dict:
    if len(bundle) < BUNDLE_HDR_SZ:
        raise ValueError("Bundle too short")
        
    (magic, session_id, t_id, a_id, t_raw_len, t_comp_len, 
     a_raw_len, a_comp_len, ext_b, stored_hash) = struct.unpack_from(BUNDLE_FMT, bundle)
    
    if magic != BUNDLE_MAGIC:
        raise ValueError("Invalid Bundle Magic")

    # Slice data
    tc = bundle[BUNDLE_HDR_SZ : BUNDLE_HDR_SZ + t_comp_len]
    ac = bundle[BUNDLE_HDR_SZ + t_comp_len : BUNDLE_HDR_SZ + t_comp_len + a_comp_len]

    # Integrity Check
    if hashlib.sha256(tc + ac).digest() != stored_hash:
        raise ValueError("SHA-256 Checksum Mismatch!")

    # Find Tele Decompressor
    t_name, t_dfn = next((n, d[2]) for n, d in TELE_ALGOS.items() if d[0] == t_id)
    # Find Audio Decompressor
    a_name, a_dfn = next((n, d[2]) for n, d in AUDIO_ALGOS.items() if d[0] == a_id)

    return {
        "session_id":     session_id.hex(),
        "tele":           t_dfn(tc),
        "audio":          a_dfn(ac),
        "tele_algo":      t_name,
        "audio_algo":     a_name,
        "audio_ext":      ext_b.rstrip(b"\x00").decode(),
        "tele_raw_len":   t_raw_len,
        "tele_comp_len":  t_comp_len,
        "audio_raw_len":  a_raw_len,
        "audio_comp_len": a_comp_len
    }