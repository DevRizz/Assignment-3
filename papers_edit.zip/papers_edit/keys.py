# keys.py - Cryptographic Key Generation
# Author: Saharsh Kumar, 3796540
# Purpose: Generate ECDSA P-256 keypairs for aircraft and ground stations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from crypto import ecdsa_keygen, save_ecdsa_keys
import config as cfg

os.makedirs("keys", exist_ok=True)

# Check if keys already exist
if os.path.exists(cfg.PRIVATE_KEY_PATH) and os.path.exists(cfg.PUBLIC_KEY_PATH):
    print("Keys already exist:")
    print(f"  Private: {cfg.PRIVATE_KEY_PATH}")
    print(f"  Public:  {cfg.PUBLIC_KEY_PATH}")
    print("\nDelete them first to regenerate.")
else:
    # Generate new keypair
    priv, pub = ecdsa_keygen()
    save_ecdsa_keys(priv, pub)
    print("ECDSA P-256 keys generated:")
    print(f"  Private key: {cfg.PRIVATE_KEY_PATH} (keep on aircraft only)")
    print(f"  Public key:  {cfg.PUBLIC_KEY_PATH} (copy to ground stations)")
    print("\nNext steps:")
    print("  1. Copy aircraft_public.pem to each ground station")
    print("  2. Start ground stations: python3 ground.py --port 9000 --name GS-Primary")
    print("  3. Start aircraft: python3 aircraft.py")