# crypto.py - Cryptographic Functions
# Author: Saharsh Kumar, 3796540
# Purpose: Handle HMAC-SHA256 per-packet authentication and ECDSA P-256 bundle signing

import hashlib
import hmac as _hmac
import os
import struct
import time

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.exceptions import InvalidSignature

import config as cfg

#HMAC-SHA256 per packet

def mac_tag(data: bytes) -> bytes:
    return _hmac.new(cfg.HMAC_KEY, data, hashlib.sha256).digest()


def mac_verify(data: bytes, tag: bytes) -> bool:
    return _hmac.compare_digest(tag, mac_tag(data))


# ── ECDSA P-256 ───────────────────────────────────────────────────────────────

def ecdsa_keygen():
    key = ec.generate_private_key(ec.SECP256R1())
    return key, key.public_key()


def ecdsa_sign(private_key, payload: bytes) -> bytes:
    digest = hashlib.sha256(payload).digest()
    return private_key.sign(digest, ec.ECDSA(hashes.SHA256()))


def ecdsa_verify(public_key, payload: bytes, sig: bytes) -> bool:
    digest = hashlib.sha256(payload).digest()
    try:
        public_key.verify(sig, digest, ec.ECDSA(hashes.SHA256()))
        return True
    except InvalidSignature:
        return False


def save_ecdsa_keys(private_key, pub_key):
    os.makedirs("keys", exist_ok=True)
    with open(cfg.PRIVATE_KEY_PATH, "wb") as f:
        f.write(private_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption()))
    with open(cfg.PUBLIC_KEY_PATH, "wb") as f:
        f.write(pub_key.public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo))


def load_ecdsa_private(path=cfg.PRIVATE_KEY_PATH):
    with open(path, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def load_ecdsa_public(path=cfg.PUBLIC_KEY_PATH):
    with open(path, "rb") as f:
        return serialization.load_pem_public_key(f.read())


# Simple benchmark function to measure ECDSA performance
def benchmark(payload: bytes, n=3):
    """Measure ECDSA P-256 signing and verification time"""
    priv, pub = ecdsa_keygen()
    
    # Benchmark signing
    t0 = time.perf_counter()
    for _ in range(n):
        sig = ecdsa_sign(priv, payload)
    sign_time_ms = (time.perf_counter() - t0) / n * 1000
    
    # Benchmark verification
    t0 = time.perf_counter()
    for _ in range(n):
        ecdsa_verify(pub, payload, sig)
    verify_time_ms = (time.perf_counter() - t0) / n * 1000
    
    return {
        "payload_bytes": len(payload),
        "ecdsa_sign_ms": round(sign_time_ms, 2),
        "ecdsa_verify_ms": round(verify_time_ms, 2),
        "ecdsa_sig_bytes": len(sig),
    }